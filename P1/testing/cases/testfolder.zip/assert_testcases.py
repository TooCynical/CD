import commands

bpath = './../bin/main'
tfpath = './cases/'

correct_output = ['2598', '3048', '2772', '3389', '4035', '4060']

for i in range(5, 11):
    output = commands.getstatusoutput(bpath + ' ' + tfpath + '/test_' + str(i))[1]
    if not (output == correct_output[i - 5]):
        print "Test failed for test" + str(i)
        print output, correct_output[i - 5]
    else:
        print "Test succeeded for test" + str(i)

correct_output = ['2128', '3008', '3033', '3474', '3090', '3773']
for i in range(5, 11):
    output = commands.getstatusoutput(bpath + ' ' + tfpath + '/testA_' + str(i))[1]
    if not (output == correct_output[i - 5]):
        print "Test failed for testA" + str(i)
        print output, correct_output[i - 5]
    else:
        print "Test succeeded for testA" + str(i)


correct_output = ['971', '1932', '1645', '2235', '3504']

for i in range(1, 6):
    output = commands.getstatusoutput(bpath + ' ' + tfpath + 'i0' + str(i))[1]
    if not (output == correct_output[i - 1]):
        print "Test failed for i0" + str(i)
        print output, correct_output[i - 1]
    else:
        print "Test succeeded for i0" + str(i)


# output = commands.getstatusoutput('./../bin/main ./cases/i07')[1]
# if not (output == '4180'):
#     print "Test failed for i07"
#     print output, '4180'
# else:
#     print "Test succeeded for i07"
